library(ggplot2)
library(viridis)


data <- data.frame(
  Cell = c("Basal keratinocyte", "Suprabasal keratinocyte", 
           "Differentiated keratinocyte", "Corneocyte",
           "Basal keratinocyte", "Suprabasal keratinocyte", 
           "Differentiated keratinocyte", "Corneocyte"),
  Value = rnorm(8)  # Example numerical values
)
type <- c(rep("Lesional" , 4) , rep("Nonlesional" , 4))
Cell <- factor(data$Cell, levels = c("Basal keratinocyte", "Suprabasal keratinocyte", "Differentiated keratinocyte", "Corneocyte"))

value <- c(788,0,820,106,646,0,449,212)
data <- data.frame(type,Cell,value)

# Grouped
a <- ggplot(data, aes(fill=Cell, y=value, x=type)) + geom_bar(position="dodge", stat="identity") + ggtitle("Numbers of skin cells") + scale_fill_manual(values=c("#e88ac4","#8da0cb","#f68d63","#65c1a4"))+
  ylab("Number of cells") + xlab("Tissue") +  theme_light() + theme(plot.title = element_text(size = 18,face = "bold")) +theme(legend.text=element_text(size=15), text = element_text(size = 17))
a


ggsave(paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/patient8/skinlesionaltypes.pdf", sep = ""), a, width = 9, height = 5)
