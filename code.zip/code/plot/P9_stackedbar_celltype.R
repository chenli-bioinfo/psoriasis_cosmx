library(ggplot2)



df <- data.frame(Tissue=c('Lesional', 'Lesional', 'Lesional', 'Lesional', 'Nonlesional', 'Nonlesional', 'Nonlesional', 'Nonlesional'),
                 Type=c('Basal keratinocyte', 'Suprabasal keratinocyte', 'Differentiated keratinocyte', 'Cornecyte', 'Basal keratinocyte', 'Suprabasal keratinocyte', 'Differentiated keratinocyte', 'Cornecyte'),
                 Proportion=c(28.6,0,60.7,10.7,36.0,0,55.4,8.6))
df

df$Type <- factor(df$Type, levels=c('Cornecyte', 'Differentiated keratinocyte', 'Suprabasal keratinocyte', 'Basal keratinocyte'))

#df$position
b <- ggplot(df, aes(x=Tissue, y=Proportion, fill=Type)) + geom_bar(position='stack', stat='identity', width = 0.6) + ggtitle("Proportions of skin cell types (%)") + theme_light() +scale_fill_manual(values=c("#65c1a4", 
                                                                                                                                                                                                          "#f68d63", 
                                                                                                                                                                                                          "#8da0cb", 
                                                                                                                                                                                                          "#e88ac4"))+theme(plot.title = element_text(size = 18,face = "bold"),text = element_text(size = 17)) + 
  theme(legend.position="none") + 
  geom_text(aes(label = Proportion), size =5, position = position_stack(vjust = 0.5))
 
b

ggsave(paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/patient9/skinlesionaltypes2.pdf", sep = ""), b, width = 5, height = 5)