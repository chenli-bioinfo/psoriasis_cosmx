package toPublishDistance;

import java.io.*;

/**
 * This is used to find t cells that are close to and far from dendritic cells (distance threshold = 150)
 * @author chenli
 * @Affiliation Monash University
 * @Date 23 Mar 2025
 */

public class Step_05_tcell_DC_distance {

	public static void main(String[] args) throws Exception
	{
		// TODO Auto-generated method stub
		String patient = "patient7";
		String con = "lesion";
		
		File cellOut1 = new File("./UPDATE/publication/output/" + patient + "/" + con + "/dist/" + patient + "_" + con + "_T cell_close_toDC.csv");
		FileWriter cellfw1 = new FileWriter(cellOut1);
		BufferedWriter cellbw1 = new BufferedWriter(cellfw1);
		
		File cellOut2 = new File("./UPDATE/publication/output/" + patient + "/" + con + "/dist/" + patient + "_" + con + "_T cell_far_toDC.csv");
		FileWriter cellfw2 = new FileWriter(cellOut2);
		BufferedWriter cellbw2 = new BufferedWriter(cellfw2);
		
		File file = new File("./UPDATE/publication/output/" + patient + "/" + con + "/dist/" + patient + "_" + con + "_Tcell_precise.csv");
		FileReader fr = new FileReader(file);
		BufferedReader br = new BufferedReader(fr);
		
		String str = br.readLine();
		//str = br.readLine();
		while(str!=null)
		{
			String tid = str.trim().replaceAll("\"", "");
			
			
			boolean flag = false;
			
			File file2 = new File("./UPDATE/publication/output/" + patient + "/" + con + "/dist/" + patient + "_" + con + "_dc_precise.csv");
			FileReader fr2 = new FileReader(file2);
			BufferedReader br2 = new BufferedReader(fr2);
			
			String s = br2.readLine();
			//s = br2.readLine();
			while(s!=null)
			{
				s = s.replaceAll("\"", "").trim();
				
				
				if(s.split("_")[1].equals(tid.split("_")[1]))
				{
					//System.out.println(tid + "--> " + s.split(",")[0]);
					//System.out.println(s);
					String location1 = findLocation(tid, patient, con);
					String location2 = findLocation(s, patient, con);
						
					double x1 = Double.parseDouble(location1.split("===")[0].trim());
					double y1 = Double.parseDouble(location1.split("===")[1].trim());
						
					double x2 = Double.parseDouble(location2.split("===")[0].trim());
					double y2 = Double.parseDouble(location2.split("===")[1].trim());
						
					double distance = Math.sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
					if(distance<=150)
					{ 
						System.out.println(tid + "  " +s);
						System.out.println(distance);
						flag = true;
						break;
					}
				}
					
				//System.out.println(location1 + "--> " + location2 + "\n");
				
				s = br2.readLine();
			}
			br2.close();
			fr2.close();
			
			if(flag)
			{
				cellbw1.write(tid + "\n");
				cellbw1.flush();
			}
			else
			{
				cellbw2.write(tid + "\n");
				cellbw2.flush();
			}
			
			//System.out.println(tid);
			str = br.readLine();
		}
		br.close();
		fr.close();
		
		cellbw1.close();
		cellfw1.close();
		cellbw2.close();
		cellfw2.close();
		
	}

	public static String findLocation(String cellID, String patient, String con) throws Exception
	{
		String location = "";
		
		File file = new File("./UPDATE/publication/output/" + patient + "/" + con + "/" + patient + "_" + con + "_Cell_Centroids_General.csv");
		FileReader fr = new FileReader(file);
		BufferedReader br = new BufferedReader(fr);
		String str = br.readLine();
		str = br.readLine();
		while(str!=null)
		{
			str = str.replaceAll("\"", "");
			if(str.split(",")[0].equals(cellID))
			{
				location = str.split(",")[2].trim() + "===" + str.split(",")[3].trim();
				break;
			}
			str = br.readLine();
		}
		br.close();
		fr.close();
		
		if(location.equals(""))
		{
			System.out.println("can't find cell: " + cellID);
			System.exit(1);
		}
		
		return location;
	}
}

