package toPublishDistance;

import java.io.*;
import java.util.LinkedHashMap;

/**
 * This file is used to generate a cell clustering file (XXXCell_Cluster_all.csv) with cell ID and cluster name
 * @author chenli
 * @Affiliation Monash University
 * @Date 23 Mar 2025
 */

public class Step_01_Replace {

	public static void main(String[] args) throws Exception
	{
		// TODO Auto-generated method stub
		String patient = "patient8";
		String con = "nonlesion";
		
		LinkedHashMap<String, String> mapCluster = new LinkedHashMap<String, String>();
		
		File cluster = new File("./UPDATE/publication/output/" + patient + "/" + con + "/" + patient + "_" + con + "_" + "Cell_Cluster_Immune.csv");
		FileReader fc=  new FileReader(cluster);
		BufferedReader bc = new BufferedReader(fc);
		String ss = bc.readLine();
		ss = bc.readLine();
		while(ss!=null)
		{
			String id = ss.split(",")[0].replaceAll("\"", "").trim();
			String cl = "IMM_" + ss.split(",")[1].replaceAll("\"", "").trim();
			
			mapCluster.put(id, cl);
			
			
			ss = bc.readLine();
		}
		bc.close();
		fc.close();
		
		File out = new File("./UPDATE/publication/output/" + patient + "/" + con + "/" + patient + "_" + con + "_" + "Cell_Cluster_all.csv");
		FileWriter fw = new FileWriter(out);
		BufferedWriter bw = new BufferedWriter(fw);
		
		
		File file = new File("./UPDATE/publication/output/" + patient + "/" + con + "/" + patient + "_" + con + "_" + "Cell_Cluster_General.csv");
		FileReader fr=  new FileReader(file);
		BufferedReader br = new BufferedReader(fr);
		String str = br.readLine();
		
		
		bw.write(str + "\n");
		bw.flush();
		
		str = br.readLine();
		while(str!=null)
		{
			String id = str.split(",")[0].replaceAll("\"", "").trim();
			String cl = str.split(",")[1].replaceAll("\"", "").trim();
			
			if(mapCluster.containsKey(id))
			{
				String name = findClusterName(mapCluster.get(id).substring(4), false, patient, con);
				bw.write(id + "," + name + "\n");
				bw.flush();
			}
			else
			{
				String name = findClusterName(cl, true, patient, con);
				bw.write(id + "," + name + "\n");
				bw.flush();
			}
			
			
			str = br.readLine();
		}
		br.close();
		fr.close();
		bw.close();
		fw.close();
	}
	
	public static String findClusterName(String id, boolean flag, String patient, String con) throws Exception
	{
		String name = "Unknown";
		if(flag)
		{
			File file = new File("./UPDATE/publication/output/" + patient + "/" + con + "/" + patient + "_" + con + "_" + "Cluster_Results_General.csv");
			FileReader fr=  new FileReader(file);
			BufferedReader br = new BufferedReader(fr);
			String str = br.readLine();
			while(str!=null)
			{
				String ss[] = str.split(",");
				if(ss[1].trim().replaceAll("\"", "").equals(id))
				{
					name = ss[2].trim();
					break;
				}
				str =br.readLine();
			}
			br.close();
			fr.close();
		}
		else
		{
			File file = new File("./UPDATE/publication/output/" + patient + "/" + con + "/" + patient + "_" + con + "_" + "Cluster_Results_Immune.csv");
			FileReader fr=  new FileReader(file);
			BufferedReader br = new BufferedReader(fr);
			String str = br.readLine();
			while(str!=null)
			{
				String ss[] = str.split(",");
				if(ss[1].trim().replaceAll("\"", "").equals(id))
				{
					name = ss[2].trim();
					break;
				}
				str = br.readLine();
			}
			br.close();
			fr.close();
		}
		return name.replaceAll(",", ";");
	}

}
