package toPublishDistance;

import java.io.*;
import java.util.LinkedHashMap;

/**
 * This is used to generate a matrix of average distances of among all cell types
 * @author chenli
 * @Affiliation Monash University
 * @Date 23 Mar 2025
 */

public class Step_02_GeneralDistance {

	public static void main(String[] args) throws Exception
	{
		// TODO Auto-generated method stub
		String patient = "patient8";
		String con = "nonlesion";
		
		File file = new File("./UPDATE/publication/output/" + patient + "/" + con + "/" + patient + "_" + con + "_" + "Cell_Centroids_General.csv");
		FileReader fr = new FileReader(file);
		BufferedReader br = new BufferedReader(fr);
		
		String str = br.readLine();
		str = br.readLine();
		
		LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
		
		while(str!=null)
		{
			String strs[] = str.split(",");
		
			map.put(strs[0].replaceAll("\"", ""), strs[2].replaceAll("\"", "") + "=" + strs[3].replaceAll("\"", ""));
		
			str = br.readLine();
		}
		br.close();
		fr.close();
		
		LinkedHashMap<String, String> mapCluster = new LinkedHashMap<String, String>();	
		File cluster = new File("./UPDATE/publication/output/" + patient + "/" + con + "/" + patient + "_" + con + "_" + "Cell_Cluster_all.csv");
		FileReader fc=  new FileReader(cluster);
		BufferedReader bc = new BufferedReader(fc);
		String ss = bc.readLine();
		ss = bc.readLine();
		while(ss!=null)
		{
			String id = ss.split(",")[0].replaceAll("\"", "").trim();
			String cl = ss.split(",")[1].replaceAll("\"", "").trim();
			if(!mapCluster.containsKey(cl))
			{
				mapCluster.put(cl, "");
			}
			
			String tmp = mapCluster.get(cl);
			if(tmp.equals(""))
			{
				tmp = id;
				mapCluster.put(cl, tmp);
			}
			else
			{
				tmp  = tmp + "," + id;
				mapCluster.put(cl, tmp);
			}
			ss = bc.readLine();
		}
		bc.close();
		fc.close();
		
		
		File out = new File("./UPDATE/publication/output/" + patient + "/" + con + "/" + patient + "_" + con + "_" + "dist_matrix.csv");
		FileWriter fw = new FileWriter(out);
		BufferedWriter bw = new BufferedWriter(fw);
		
		
		String title = "cell";
		for(String key:mapCluster.keySet())
		{
			title = title + "," + key;
		}
		System.out.println(title);
		bw.write(title + "\n");
		bw.flush();
		
		for(int i = 1 ; i <=title.split(",").length-1; i++)
		{
			String toWrite = title.split(",")[i];
			for(int j = 1; j <=title.split(",").length-1; j++)
			{
				System.out.println(title.split(",")[i] + " -> " + title.split(",")[j]);
				int count = 0;
				double sumDist = 0.0;
				double countIdentical = 0;	
				
				String id1s[] = mapCluster.get(title.split(",")[i]).split(",");
				String id2s[] = mapCluster.get(title.split(",")[j]).split(",");
						
				if(!title.split(",")[i].equals(title.split(",")[j]))
				{
					for(int m = 0 ; m <id1s.length; m++)
					{
						for(int n = 0; n < id2s.length; n++)
						{
							
							if(!id1s[m].equals(id2s[n]))
							{
								count++;
								double x1 = Double.parseDouble(map.get(id1s[m]).split("=")[0].trim());
								double y1 = Double.parseDouble(map.get(id1s[m]).split("=")[1].trim());
								double x2 = Double.parseDouble(map.get(id2s[n]).split("=")[0].trim());
								double y2 = Double.parseDouble(map.get(id2s[n]).split("=")[1].trim());
										
								double dis = Math.sqrt((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2));
								sumDist = sumDist + dis;
							}
							else
							{
								countIdentical ++;
							}
						}
					}
					System.out.println(id1s.length*id2s.length + "  " + countIdentical);
					System.out.println("unique pairs: " + count + " All distance: " + sumDist + " Mean: " + (sumDist/count));
					toWrite = toWrite + "," + (sumDist/count);
				}
				else
				{
					for(int m = 0 ; m <id1s.length; m++)
					{
						for(int n = m+1; n < id2s.length; n++)
						{
							
							if(!id1s[m].equals(id2s[n]))
							{
								count++;
								double x1 = Double.parseDouble(map.get(id1s[m]).split("=")[0].trim());
								double y1 = Double.parseDouble(map.get(id1s[m]).split("=")[1].trim());
								double x2 = Double.parseDouble(map.get(id2s[n]).split("=")[0].trim());
								double y2 = Double.parseDouble(map.get(id2s[n]).split("=")[1].trim());
										
								double dis = Math.sqrt((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2));
								sumDist = sumDist + dis;
							}
							else
							{
								countIdentical ++;
							}
						}
					}
					System.out.println(id1s.length*id2s.length + "  " + countIdentical);
					System.out.println("unique pairs: " + count + " All distance: " + sumDist + " Mean: " + (sumDist/count));
					toWrite = toWrite + "," + (sumDist/count);
				}
				
				
				
			}

			bw.write(toWrite + "\n");
			bw.flush();
		}
		bw.close();
		fw.close();
	}

}
