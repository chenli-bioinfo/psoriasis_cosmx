library(Seurat)
library(tidyverse)
library(HGNChelper)

patient <- "patient11"
condition <- "lesion"
patientID <- "11"

### 1. loading the data
nano.obj <- LoadNanostring(data.dir=paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/data/", patient, "/", condition, "/", sep = ""), fov= condition, assay = "Nanostring")
row.names(nano.obj)

### 2. Pre-processing
nano.obj <- SCTransform(nano.obj, assay = "Nanostring", clip.range = c(-10, 10), verbose = FALSE)



### 3. Run PCA
nano.obj <- RunPCA(nano.obj, npcs = 50);
ElbowPlot(nano.obj)
nano.obj <- RunUMAP(nano.obj, dims = 1:20)
nano.obj <- FindNeighbors(nano.obj, reduction = "pca", dims= 1:20, compute.SNN = TRUE)
nano.obj <- FindClusters(nano.obj,resolution = 0.3)


DimPlot(nano.obj, raster = FALSE, label = TRUE) + ggtitle(paste("Patient", patientID, condition))
ImageDimPlot(nano.obj, fov = condition, cols = "glasbey")



#Cell.set1 <- read.csv("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/patient11/lesion/dist/SK_close_toBK.csv",header=F)$V1
#Cell.set1
#Cell.set2 <- read.csv("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/patient11/lesion/dist/basal keratinocytes_IDs.csv",header=F)$V1
#All.cells <- colnames(nano.obj)
#All.cells
#New.Group <- rep("Others", length(All.cells))
#names(New.Group) <- All.cells
#New.Group[Cell.set1] <- "SK adjacent to BKs"
#New.Group[Cell.set2] <- "BK"
#Col.vec <- c('red','blue','gray')
#names(Col.vec) <- c('SK adjacent to BKs','BK','Others')
#nano.obj[['Cell']] <- New.Group
#plotImage <- ImageDimPlot(nano.obj, group.by='Cell', col=Col.vec,size = 1.1)
#ggsave("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/patient11/lesion/dist/SK_close_toBK.png", plotImage, width = 10, height = 6, dpi=900)

Cell.set1 <- read.csv("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/patient11/lesion/dist/SK_far_toBK.csv",header=F)$V1
Cell.set1
Cell.set2 <- read.csv("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/patient11/lesion/dist/basal keratinocytes_IDs.csv",header=F)$V1
All.cells <- colnames(nano.obj)
All.cells
New.Group <- rep("Others", length(All.cells))
names(New.Group) <- All.cells
New.Group[Cell.set1] <- "SK far from BKs"
New.Group[Cell.set2] <- "BK"
Col.vec <- c('green','blue','gray')
names(Col.vec) <- c('SK far from BKs','BK','Others')
nano.obj[['Cell']] <- New.Group
plotImage <- ImageDimPlot(nano.obj, group.by='Cell', col=Col.vec,size = 1.1)
ggsave("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/patient11/lesion/dist/SK_far_toBK.png", plotImage, width = 10, height = 6, dpi=900)