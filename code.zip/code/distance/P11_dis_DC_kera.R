library(Seurat)
library(tidyverse)
library(HGNChelper)

patient <- "patient11"
condition <- "lesion"
patientID <- "11"

### 1. loading the data
nano.obj <- LoadNanostring(data.dir=paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/data/", patient, "/", condition, "/", sep = ""), fov= condition, assay = "Nanostring")
row.names(nano.obj)

### 2. Pre-processing
nano.obj <- SCTransform(nano.obj, assay = "Nanostring", clip.range = c(-10, 10), verbose = FALSE)



### 3. Run PCA
nano.obj <- RunPCA(nano.obj, npcs = 50);
ElbowPlot(nano.obj)
nano.obj <- RunUMAP(nano.obj, dims = 1:20)
nano.obj <- FindNeighbors(nano.obj, reduction = "pca", dims= 1:20, compute.SNN = TRUE)
nano.obj <- FindClusters(nano.obj,resolution = 0.3)


DimPlot(nano.obj, raster = FALSE, label = TRUE) + ggtitle(paste("Patient", patientID, condition))
ImageDimPlot(nano.obj, fov = condition, cols = "glasbey")



#Cell.set1 <- read.csv("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/patient11/lesion/dist/DC_close_tokera.csv",header=F)$V1
#Cell.set1
#Cell.set2 <- read.csv("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/patient11/lesion/dist/Basal keratinocyte_cell_IDs.csv",header=F)$V1
#All.cells <- colnames(nano.obj)
#All.cells
#New.Group <- rep("Others", length(All.cells))
#names(New.Group) <- All.cells
#New.Group[Cell.set1] <- "Dendritic cell adjacent to Basal K"
#New.Group[Cell.set2] <- "Basal K"
#Col.vec <- c('red','blue','gray')
#names(Col.vec) <- c('Dendritic cell adjacent to Basal K','Basal K','Others')
#nano.obj[['Cell']] <- New.Group
#plotImage <- ImageDimPlot(nano.obj, group.by='Cell', col=Col.vec,size = 0.8)
#ggsave("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/patient11/lesion/dist/DC_close_tokera.png", plotImage, width = 10, height = 6, dpi=900)

Cell.set1 <- read.csv("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/patient11/lesion/dist/DC_far_tokera.csv",header=F)$V1
Cell.set1
Cell.set2 <- read.csv("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/patient11/lesion/dist/Basal keratinocyte_cell_IDs.csv",header=F)$V1
All.cells <- colnames(nano.obj)
All.cells
New.Group <- rep("Others", length(All.cells))
names(New.Group) <- All.cells
New.Group[Cell.set1] <- "Dendritic cell far from T cells"
New.Group[Cell.set2] <- "T cell"
Col.vec <- c('green','blue','gray')
names(Col.vec) <- c('Dendritic cell far from T cells','T cell','Others')
nano.obj[['Cell']] <- New.Group
plotImage <- ImageDimPlot(nano.obj, group.by='Cell', col=Col.vec,size = 0.8)
ggsave("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/patient11/lesion/dist/DC_far_tokera.png", plotImage, width = 10, height = 6, dpi=900)
