library(Seurat)
library(tidyverse)
library(HGNChelper)

patient <- "patient9"
condition <- "lesion"
patientID <- "9"

### 1. loading the data
nano.obj <- LoadNanostring(data.dir=paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/data/", patient, "/", condition, "/", sep = ""), fov= condition, assay = "Nanostring")
row.names(nano.obj)

### 2. Pre-processing
nano.obj <- SCTransform(nano.obj, assay = "Nanostring", clip.range = c(-10, 10), verbose = FALSE)



### 3. Run PCA
nano.obj <- RunPCA(nano.obj, npcs = 50);
ElbowPlot(nano.obj)
nano.obj <- RunUMAP(nano.obj, dims = 1:20)
nano.obj <- FindNeighbors(nano.obj, reduction = "pca", dims= 1:20, compute.SNN = TRUE)
nano.obj <- FindClusters(nano.obj,resolution = 0.3)


DimPlot(nano.obj, raster = FALSE, label = TRUE) + ggtitle(paste("Patient", patientID, condition))
ImageDimPlot(nano.obj, fov = condition, cols = "glasbey")



Cell.set1 <- read.csv(paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/", patient, "/", condition, "/dist/", patient, "_", condition, "_T cell_close_toBasal keratinocyte.csv", sep=""),header=F)$V1
Cell.set1
Cell.set2 <- read.csv(paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/", patient, "/", condition, "/dist/", patient, "_", condition, "_Basal keratinocyte_cell_IDs.csv", sep=""),header=F)$V1
All.cells <- colnames(nano.obj)
All.cells
New.Group <- rep("Others", length(All.cells))
names(New.Group) <- All.cells
New.Group[Cell.set1] <- "T cell adjacent to basal keratinocytes"
New.Group[Cell.set2] <- "Basal keratinocyte"
Col.vec <- c('red','blue','#676767')
names(Col.vec) <- c('T cell adjacent to basal keratinocytes','Basal keratinocyte','Others')
nano.obj[['Cell']] <- New.Group
plotImage <- ImageDimPlot(nano.obj, group.by='Cell', col=Col.vec,size = 0.8)
ggsave(paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/", patient, "/", condition, "/dist/", patient, "_", condition, "_T cell_close_toBasal keratinocyte.png", sep=""), plotImage, width = 10, height = 6, dpi=900)

#Cell.set1 <- read.csv(paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/", patient, "/", condition, "/dist/", patient, "_", condition, "_T cell_far_toBasal keratinocyte.csv", sep=""),header=F)$V1
#Cell.set1
#Cell.set2 <- read.csv(paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/", patient, "/", condition, "/dist/", patient, "_", condition, "_Basal keratinocyte_cell_IDs.csv", sep=""),header=F)$V1
#All.cells <- colnames(nano.obj)
#All.cells
#New.Group <- rep("Others", length(All.cells))
#names(New.Group) <- All.cells
#New.Group[Cell.set1] <- "T cell far from basal keratinocytes"
#New.Group[Cell.set2] <- "Basal keratinocyte"
#Col.vec <- c('green','blue','#676767')
#names(Col.vec) <- c('T cell far from basal keratinocytes','Basal keratinocyte','Others')
#nano.obj[['Cell']] <- New.Group
#plotImage <- ImageDimPlot(nano.obj, group.by='Cell', col=Col.vec,size = 0.8)
#ggsave(paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/", patient, "/", condition, "/dist/", patient, "_", condition, "_T cell_far_toBasal keratinocyte.png", sep=""), plotImage, width = 10, height = 6, dpi=900)
