library(dplyr)
library(ggplot2)
library(reshape)
library(viridis)

patient <- "patient8"
condition <- "nonlesion"

df <- read.csv(paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/", patient, "/", condition, "/", patient, "_", condition, "_dist_matrix.csv", sep = ""), header=TRUE, check.names=FALSE)


df$cell <- factor(df$cell, levels = unique(df$cell))

df_melt <- melt(df)
suppressWarnings(max(df_melt[,3]))
library(viridis)
#ggplot(df_melt, aes(x=variable, y=cell, fill= factor(value))) + geom_tile() + scale_fill_manual(values = c("0" = "white", "1" = "red"))
heatmap <- ggplot(df_melt, aes(x=variable, y=cell, fill= value)) + geom_tile(color = "white", lwd = 1.5, linetype = 1) + 
  #geom_text(aes(label = round(value,1)), color = "white", size = 4) 
 scale_fill_viridis_c(name = "Distance") + 
  theme(axis.text=element_text(size=15,face="bold"), axis.text.x = element_text(angle =30, vjust = 0.5), axis.title.x=element_blank(),
        axis.title.y=element_blank(),legend.text=element_text(size=12,face="bold"), legend.title = element_text(size=12,face = "bold"),
        panel.background = element_blank()) 
heatmap
ggsave(paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/", patient, "/", condition, "/", patient, "_", condition, "_distance_forFigure.pdf", sep = ""), heatmap, width =15, height = 6)


