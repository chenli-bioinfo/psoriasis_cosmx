library(Seurat)
library(tidyverse)
library(HGNChelper)

patient <- "patient11"
condition <- "lesion"
patientID <- "11"

### 1. loading the data
nano.obj <- LoadNanostring(data.dir=paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/data/", patient, "/", condition, "/", sep = ""), fov= condition, assay = "Nanostring")
row.names(nano.obj)

### 2. Pre-processing
nano.obj <- SCTransform(nano.obj, assay = "Nanostring", clip.range = c(-10, 10), verbose = FALSE)



### 3. Run PCA
nano.obj <- RunPCA(nano.obj, npcs = 50);
ElbowPlot(nano.obj)
nano.obj <- RunUMAP(nano.obj, dims = 1:20)
nano.obj <- FindNeighbors(nano.obj, reduction = "pca", dims= 1:20, compute.SNN = TRUE)
nano.obj <- FindClusters(nano.obj,resolution = 0.3)


DimPlot(nano.obj, raster = FALSE, label = TRUE) + ggtitle(paste("Patient", patientID, condition))
ImageDimPlot(nano.obj, fov = condition, cols = "glasbey")


Cell.set1 <- read.csv("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/patient11/lesion/dist/SK_close_toBK.csv",header=F)$V1
Cell.set2 <- read.csv("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/patient11/lesion/dist/SK_far_toBK.csv",header=F)$V1

#Cell.set3 <- read.csv("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/patient11/lesion/dist/Basal keratinocyte_cell_IDs.csv",header=F)$V1

markers <- FindMarkers(nano.obj, ident.1 = Cell.set1, ident.2 =Cell.set2, logfc.threshold = 0.25)
markers

write.csv(markers,"/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/patient11/lesion/dist/P11_lesion_SK_close and far_BK.csv", row.names = TRUE)

