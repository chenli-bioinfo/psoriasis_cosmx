library(Seurat)
library(tidyverse)
library(HGNChelper)
library(viridis)

patient <- "patient9"
condition <- "nonlesion"
conditionfull <- "nonlesional"

### 1. loading the data
nano.obj <- LoadNanostring(data.dir=paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/data/", patient, "/", condition, "/", sep = ""), fov= condition, assay = "Nanostring")
row.names(nano.obj)

### 2. Pre-processing
nano.obj <- SCTransform(nano.obj, assay = "Nanostring", clip.range = c(-10, 10), verbose = FALSE)

### 3. Run PCA
nano.obj <- RunPCA(nano.obj, npcs = 50);
ElbowPlot(nano.obj)

### 4. Run UMAP
nano.obj <- RunUMAP(nano.obj, dims = 1:20)

### 5. Find Neighbors
nano.obj <- FindNeighbors(nano.obj, reduction = "pca", dims= 1:20, compute.SNN = TRUE)

### 6. Find Clusters
nano.obj <- FindClusters(nano.obj,resolution = 0.3)

plotCluster <- DimPlot(nano.obj, raster = FALSE, label = TRUE) + ggtitle(paste("Patient #2", conditionfull))
ggsave(paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/", patient, "/", condition, "/", patient, "_", condition, "_", "Cell_Cluster_General.pdf", sep = ""), plotCluster, width = 6, height = 6)

plotImage <- ImageDimPlot(nano.obj, fov = condition, cols = "glasbey")
ggsave(paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/", patient, "/", condition, "/", patient, "_", condition, "_", "Cell_Image_General.pdf", sep = ""), plotImage, width = 6, height = 6)


### 7.Find marker genes and build the heatmap
All.markers <- FindAllMarkers(nano.obj, only.pos = TRUE, min.pct = 0.25, logfc.threshold = 0.25)

All.markers %>% group_by(cluster) %>% top_n(2, avg_log2FC)
top10 <- All.markers %>% group_by(cluster) %>% top_n(10, avg_log2FC)
eee <- DoHeatmap(object = nano.obj, features = top10$gene) + scale_fill_viridis() + guides(color="none") + theme(text = element_text(size = 12)) + theme(legend.position = 'bottom')
ggsave(paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/", patient, "/", condition, "/", patient, "_", condition, "_", "Heatmap_General_forFigure.png", sep = ""), eee, width = 4, height = 10)

### 8. Naming general cluster names
# load gene set preparation function
source("https://raw.githubusercontent.com/IanevskiAleksandr/sc-type/master/R/gene_sets_prepare.R")
# load cell type annotation function
source("https://raw.githubusercontent.com/IanevskiAleksandr/sc-type/master/R/sctype_score_.R")

# DB file
#db_ = "https://raw.githubusercontent.com/IanevskiAleksandr/sc-type/master/ScTypeDB_full.xlsx";
#db_ = "/Users/chenli/Downloads/new.xlsx";
#db_ = "/Users/chenli/eclipse-workspace/Psoriasis_nanostring/raw data/skin marker gene/asolina/markergenes.xlsx"
db_ = "/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/geneList20240916/final/Final_gene_marker_general.xlsx"
#db_ = "/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/geneList20240916/final/all_markers.xlsx"
tissue = "Skin" # e.g. Immune system,Pancreas,Liver,Eye,Kidney,Brain,Lung,Adrenal,Heart,Intestine,Muscle,Placenta,Spleen,Stomach,Thymus 

# prepare gene sets
gs_list = gene_sets_prepare(db_, tissue)

#saveRDS(pbmc,"/Users/chenli/Downloads/SMI-0163_AsolinaBraun_MonashU_CosMx/filtered_gene_bc_matrices/hg19/pbmc.rds")

# get cell-type by cell matrix
es.max = sctype_score(scRNAseqData = nano.obj[["SCT"]]@scale.data, scaled = TRUE, 
                      gs = gs_list$gs_positive, gs2 = gs_list$gs_negative)

# merge by cluster
cL_resutls = do.call("rbind", lapply(unique(nano.obj@meta.data$seurat_clusters), function(cl){
  es.max.cl = sort(rowSums(es.max[ ,rownames(nano.obj@meta.data[nano.obj@meta.data$seurat_clusters==cl, ])]), decreasing = !0)
  head(data.frame(cluster = cl, type = names(es.max.cl), scores = es.max.cl, ncells = sum(nano.obj@meta.data$seurat_clusters==cl)), 10)
}))
sctype_scores = cL_resutls %>% group_by(cluster) %>% top_n(n = 1, wt = scores)  

# set low-confident (low ScType score) clusters to "unknown"
sctype_scores$type[as.numeric(as.character(sctype_scores$scores)) < sctype_scores$ncells/4] = "Others_1"
print(sctype_scores[,1:3])

nano.obj@meta.data$customclassif = ""
for(j in unique(sctype_scores$cluster)){
  cl_type = sctype_scores[sctype_scores$cluster==j,]; 
  nano.obj@meta.data$customclassif[nano.obj@meta.data$seurat_clusters == j] = as.character(cl_type$type[1])
}
write.csv(sctype_scores, paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/", patient, "/", condition, "/", patient, "_", condition, "_","Cluster_Results_General.csv", sep = ""), row.names=TRUE)
write.csv(nano.obj@images[[condition]]@boundaries[["centroids"]]@coords, paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/", patient, "/", condition, "/", patient, "_", condition, "_", "Cell_Centroids_General.csv", sep = ""), row.names=TRUE)
write.csv(nano.obj@active.ident, paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/", patient, "/", condition, "/", patient, "_", condition, "_", "Cell_Cluster_General.csv", sep = ""), row.names=TRUE)

cellimage <- ImageDimPlot(nano.obj, fov = condition, size=2, border.size = 0)+
scale_fill_brewer(palette = "Set1", labels=c('Differentiated keratinocyte', 'Immune-related cell', 'Fibroblast', 'Basal keratinocyte', 'Others_1', 'Corneocyte'), name="Cell Cluster") + 
theme(legend.text=element_text(size=18), legend.title = element_text(size=18))
ggsave(paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/", patient, "/", condition, "/", patient, "_", condition, "_", "Cell_Image_General_forFigure.pdf", sep = ""), cellimage, width = 20, height = 10)

cell_naming <- DimPlot(nano.obj, reduction = "umap", label = TRUE, repel = TRUE, group.by = 'customclassif', label.size=7) + ggtitle(paste("Patient #2", conditionfull)) + NoLegend() + theme(plot.title = element_text(size = 20, face = "bold"))
ggsave(paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/", patient, "/", condition, "/", patient, "_", condition, "_", "Cell_Naming_General_forFigure.pdf", sep = ""), cell_naming, width = 6, height = 6)

ridgeplot<-RidgePlot(nano.obj, features = c("CD74","MARCKSL1","SELENOP","CXCL12","JCHAIN","CD34","CD52","UBE2C","PECAM1","LYVE1","GNLY","AZU1","CD1C","COTL1","HLA-DPA1","HLA-DRB","HLA-DPB1","HLA-DQA1","HLA-DQB1/2","HLA-DRA","CCR7","IRF4","COL6A2","CCL19","MZB1","IL32","IFITM1","CD44","CD3D","CD3E","CD3G","CCL21","KRT23","KRT86","KRT10","KRT16","KRT18","KRT15","KRT1","KRT14","KRT20","KRT17","KRT7","KRT19","KRT5","KRT13","KRT8","KRT80","KRT4","KRT6A/B/C") , ncol = 3)
ggsave(paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/", patient, "/", condition, "/", patient, "_", condition, "_", "Genes_General_forFigure.pdf", sep = ""), ridgeplot, width = 15, height = 49)



### 9. Immune cell############################
##############################################
##############################################
nano.obj.subset <- subset(nano.obj, idents = c("1"))

###using specific gene contraints for find precise immnue cells
tcells <- WhichCells(object = nano.obj.subset, expression = (CD3E > 0.5 | CD3D >0.5 | CD3G >0.5) & (IL32>0.5 | CD52>0.5) , slot = 'data')
write.csv(tcells, paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/", patient, "/", condition, "/dist/", patient, "_", condition, "_", "Tcell_precise.csv", sep = ""), row.names=TRUE)

cd4cells<- WhichCells(object = nano.obj.subset, expression = ( CD3E > 0.5 | CD3D >0.5 | CD3G >0.5 ) &  (IL32>0.5 | CD52>0.5) & CD4>0.5 &  (CD8A<0.5 & CD8B <0.5 ), slot = 'data')
write.csv(cd4cells, paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/", patient, "/", condition, "/dist/", patient, "_", condition, "_", "cd4cell_precise.csv", sep = ""), row.names=TRUE)

cd8cells<- WhichCells(object = nano.obj.subset, expression = ( CD3E > 0.5 | CD3D >0.5 | CD3G >0.5 ) &  (IL32>0.5 | CD52>0.5) &  (CD8A>0.5 | CD8B >0.5 ) & CD4<0.5 , slot = 'data')
write.csv(cd8cells, paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/", patient, "/", condition, "/dist/", patient, "_", condition, "_", "cd8cell_precise.csv", sep = ""), row.names=TRUE)

DC <- WhichCells(object = nano.obj.subset, expression = (CD74 > 2) & (`HLA-DRB`>0.5 | `HLA-DPA1`>0.5 | `HLA-DRA`>0.5 | `HLA-DQB1/2`>0.5 | `HLA-DQA1`>0.5 | `HLA-DPB1`>0.5), slot = 'data')
write.csv(DC, paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/", patient, "/", condition, "/dist/", patient, "_", condition, "_", "dc_precise.csv", sep = ""), row.names=TRUE)

#FeaturePlot(nano.obj.subset, pt.size = 0.2, feature = c("HLA-DRB","HLA-DPA1", "HLA-DRA", "HLA-DQB1/2", "HLA-DQA1", "HLA-DPB1", "CD74"), ncol=3) | DimPlot(nano.obj.subset, cells.highlight= DC, cols.highlight = "red", cols= "grey") + ggtitle("Dendritic cells")
entirePlot <- (DimPlot(nano.obj.subset, cells.highlight= tcells, cols.highlight = "green", cols= "grey") + ggtitle("T cells") + NoLegend() | DimPlot(nano.obj.subset, cells.highlight= DC, cols.highlight = "red", cols= "grey") + ggtitle("Dendritic cells") + NoLegend())
ggsave(paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/", patient, "/", condition, "/dist/", patient, "_", condition, "_", "precise_cells.pdf", sep = ""), entirePlot, width = 15, height = 4)

nano.obj.subset <- SCTransform(nano.obj.subset, assay = "Nanostring", clip.range = c(-10, 10), verbose = FALSE)

nano.obj.subset <- FindNeighbors(nano.obj.subset, reduction = "pca", dims= 1:20, compute.SNN = TRUE)

nano.obj.subset <- FindClusters(nano.obj.subset,resolution = 0.3)

plotCluster_sub <- DimPlot(nano.obj.subset, raster = FALSE, label = TRUE) + ggtitle(paste("Patient #2", conditionfull, "immune-related cells"))
ggsave(paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/", patient, "/", condition, "/", patient, "_", condition, "_", "Cell_Cluster_Immune.pdf", sep = ""), plotCluster_sub, width = 6, height = 6)

plotImage_sub <- ImageDimPlot(nano.obj.subset, fov = condition, cols = "glasbey")
ggsave(paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/", patient, "/", condition, "/", patient, "_", condition, "_", "Cell_Image_Immune.pdf", sep = ""), plotImage_sub, width = 6, height = 6)


### in some cases, for example nonlesion, it is possible that no markers can be found it there is only one cluster
All.markers_sub <- FindAllMarkers(nano.obj.subset, only.pos = TRUE, min.pct = 0.25, logfc.threshold = 0.25)
write.csv(All.markers_sub, paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/", patient, "/", condition, "/", patient, "_", condition, "_", "Marker_Genes_Immune.csv", sep = ""), row.names=TRUE)

All.markers_sub %>% group_by(cluster) %>% top_n(2, avg_log2FC)
top10 <- All.markers_sub %>% group_by(cluster) %>% top_n(10, avg_log2FC)
fff <- DoHeatmap(object = nano.obj.subset, features = top10$gene) + scale_fill_viridis() + guides(color="none") + theme(text = element_text(size = 12)) + theme(legend.position = 'bottom')
ggsave(paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/", patient, "/", condition, "/", patient, "_", condition, "_", "Heatmap_Immune_forFigure.png", sep = ""), fff, width = 4, height = 10)


# load gene set preparation function
source("https://raw.githubusercontent.com/IanevskiAleksandr/sc-type/master/R/gene_sets_prepare.R")
# load cell type annotation function
source("https://raw.githubusercontent.com/IanevskiAleksandr/sc-type/master/R/sctype_score_.R")

# DB file
#db_ = "https://raw.githubusercontent.com/IanevskiAleksandr/sc-type/master/ScTypeDB_full.xlsx";
#db_ = "/Users/chenli/Downloads/new.xlsx";
db_ = "/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/geneList20240916/final/Final_gene_marker_immune2.xlsx"
tissue = "Skin" # e.g. Immune system,Pancreas,Liver,Eye,Kidney,Brain,Lung,Adrenal,Heart,Intestine,Muscle,Placenta,Spleen,Stomach,Thymus 

# prepare gene sets
gs_list = gene_sets_prepare(db_, tissue)

#saveRDS(pbmc,"/Users/chenli/Downloads/SMI-0163_AsolinaBraun_MonashU_CosMx/filtered_gene_bc_matrices/hg19/pbmc.rds")

# get cell-type by cell matrix
es.max = sctype_score(scRNAseqData = nano.obj.subset[["SCT"]]@scale.data, scaled = TRUE, 
                      gs = gs_list$gs_positive, gs2 = gs_list$gs_negative)

# merge by cluster
cL_resutls = do.call("rbind", lapply(unique(nano.obj.subset@meta.data$seurat_clusters), function(cl){
  es.max.cl = sort(rowSums(es.max[ ,rownames(nano.obj.subset@meta.data[nano.obj.subset@meta.data$seurat_clusters==cl, ])]), decreasing = !0)
  head(data.frame(cluster = cl, type = names(es.max.cl), scores = es.max.cl, ncells = sum(nano.obj.subset@meta.data$seurat_clusters==cl)), 10)
}))
sctype_scores_sub = cL_resutls %>% group_by(cluster) %>% top_n(n = 1, wt = scores)  

# set low-confident (low ScType score) clusters to "unknown"
sctype_scores_sub$type[as.numeric(as.character(sctype_scores_sub$scores)) < sctype_scores_sub$ncells/4] = "Others_2"
print(sctype_scores_sub[,1:3])

nano.obj.subset@meta.data$customclassif = ""
for(j in unique(sctype_scores_sub$cluster)){
  cl_type_sub = sctype_scores_sub[sctype_scores_sub$cluster==j,]; 
  nano.obj.subset@meta.data$customclassif[nano.obj.subset@meta.data$seurat_clusters == j] = as.character(cl_type_sub$type[1])
}

write.csv(sctype_scores_sub, paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/", patient, "/", condition, "/", patient, "_", condition, "_", "Cluster_Results_Immune.csv", sep = ""), row.names=TRUE)
write.csv(nano.obj.subset@active.ident, paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/", patient, "/", condition, "/", patient, "_", condition, "_", "Cell_Cluster_Immune.csv", sep = ""), row.names=TRUE)
write.csv(nano.obj.subset@images[[condition]]@boundaries[["centroids"]]@coords, paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/", patient, "/", condition, "/", patient, "_", condition, "_", "Cell_Centroids_Immune.csv", sep = ""), row.names=TRUE)


cellimage_sub <- ImageDimPlot(nano.obj.subset, fov = condition, cols = "glasbey", size=2, border.size = 0) +
  scale_fill_brewer(palette = "Set1", labels=c('Others_2', 'Macrophage', 'Basophil', 'Granulocyte', 'Lymphatic endothelial cell'), name="Cell Cluster") + 
  theme(legend.text=element_text(size=18), legend.title = element_text(size=18))
ggsave(paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/", patient, "/", condition, "/", patient, "_", condition, "_", "Cell_Image_Immune_forFigure.pdf", sep = ""), cellimage_sub, width = 20, height = 10)

cell_naming_sub <- DimPlot(nano.obj.subset, reduction = "umap", label = TRUE, repel = TRUE, group.by = 'customclassif', label.size = 7) + ggtitle(paste("Patient #2", conditionfull, "immune-related cells")) + NoLegend() + theme(plot.title = element_text(size = 20, face = "bold"))
ggsave(paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/", patient, "/", condition, "/", patient, "_", condition, "_", "Cell_Naming_Immune_forFigure.pdf", sep = ""), cell_naming_sub, width = 7, height = 6)

ridgeplot_sub <- RidgePlot(nano.obj.subset, features = c("CD74","MARCKSL1","SELENOP","CXCL12","JCHAIN","CD34","CD52","UBE2C","PECAM1","LYVE1","GNLY","AZU1","CD1C","COTL1","HLA-DPA1","HLA-DRB","HLA-DPB1","HLA-DQA1","HLA-DQB1/2","HLA-DRA","CCR7","IRF4","COL6A2","CCL19","MZB1","IL32","IFITM1","CD44","CD3D","CD3E","CD3G","CCL21","KRT23","KRT86","KRT10","KRT16","KRT18","KRT15","KRT1","KRT14","KRT20","KRT17","KRT7","KRT19","KRT5","KRT13","KRT8","KRT80","KRT4","KRT6A/B/C") , ncol = 3)
ggsave(paste("/Users/chenli/eclipse-workspace/Psoriasis_nanostring/UPDATE/publication/output/", patient, "/", condition, "/", patient, "_", condition, "_", "Genes_Immune_forFigure.pdf", sep = ""), ridgeplot_sub, width = 15, height = 49)